export default {
  onBoardingLight1: require('./onBordingLight1.png'),
  onBoardingLight2: require('./onBordingLight2.png'),
  onBoardingLight3: require('./onBordingLight3.png'),
  userDark: require('./userDark.png'),
  userLight: require('./userLight.png'),
  post: require('./post.png'),
  music: require('./music.png'),
  musicTone: require('./musicTone.png'),
  liveBg: require('./liveBg.png'),
};
