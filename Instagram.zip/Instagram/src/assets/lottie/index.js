export default {
  pauseRing: require('./pauseRing.json'),
  playRing: require('./activeRing.json'),
};
