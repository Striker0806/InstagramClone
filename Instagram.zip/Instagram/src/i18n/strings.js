import LocalizedStrings from 'react-native-localization';
import enI18n from './en';

export default strings = new LocalizedStrings({
  en: enI18n,
});
